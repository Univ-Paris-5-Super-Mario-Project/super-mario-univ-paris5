# HTML 5 Super Mario Game

A project built at University Paris Descartes (Paris, France) by:
* Xavier Lefebvre
* Alexis Le Bars
* Thomas Riccioli
* Conrad Kleinespel

With the help of:
* Hervé Suaudeau

Any comments, PR or bug reports are appreciated! :-)

## License

The source code is released under the GPL v3 license. See [`license.md`](LICENSE.md) for more information.